library(ggplot2)
library(dplyr)
library(readxl)

df_data <- read_excel("확통_은행신용도.xls")
raw_data <- df_data

df_data
head(df_data, 10)
tail(df_data, 10)
str(df_data)
summary(df_data)

is.na(df_data)
table(is.na(df_data$신용도))
table(is.na(df_data$근무년수))
table(is.na(df_data$고객년수))
table(is.na(df_data$교육년수))
table(is.na(df_data$거주년수))
table(is.na(df_data$연령))
table(is.na(df_data$수입))
table(is.na(df_data$집세))
table(is.na(df_data$주택소유))
table(is.na(df_data$신용카드))
table(is.na(df_data$결혼상태))
table(is.na(df_data$고객번호))


df_data <- df_data %>% 
  filter(!is.na(신용도) & !is.na(주택소유) & !is.na(신용카드) & !is.na(결혼상태) & !is.na(고객번호))

boxplot(df_data$집세)$stats
df_data$집세 <- ifelse(df_data$집세 < 0 | df_data$집세 > 509, NA, df_data$집세)
mean(df_data$집세, na.rm = T)
df_data$집세<- ifelse(is.na(df_data$집세), 282, df_data$집세)
table(is.na(df_data$집세))

boxplot(df_data$수입)$stats
df_data$수입 <- ifelse(df_data$수입 < 0 | df_data$수입 > 509, NA, df_data$수입)
mean(df_data$수입, na.rm = T)
df_data$수입  <- ifelse(is.na(df_data$수입),437 , df_data$수입)

boxplot(df_data$연령)$stats
df_data$연령 <- ifelse(df_data$연령 > 50, NA, df_data$연령)
mean(df_data$연령, na.rm = T)
df_data$연령 <- ifelse(is.na(df_data$연령), 31, df_data$연령)

boxplot(df_data$거주년수)$stats
df_data$거주년수 <- ifelse(df_data$거주년수 > 800, NA, df_data$거주년수)
mean(df_data$거주년수, na.rm = T)
df_data$거주년수  <- ifelse(is.na(df_data$거주년수),7 , df_data$거주년수)

boxplot(df_data$교육년수)$stats
mean(df_data$교육년수, na.rm = T)
df_data$교융년수  <- ifelse(is.na(df_data$교육년수), 16, df_data$교육년수)

boxplot(df_data$근무년수)$stats
mean(df_data$근무년수 , na.rm = T)
df_data$근무년수  <- ifelse(is.na(df_data$근무년수), 5, df_data$근무년수)





df_data %>% 
  group_by(결혼상태) %>% 
  summarise(mean_집세 = mean(집세))

ggplot(data = df_data, aes(x = 결혼상태, y = 수입)) + geom_col()

ggplot(data = df_data, aes(x = 거주년수, y = 집세)) + geom_line()

ggplot(data = df_data, aes(x = 교육년수, y = 수입)) + geom_line()

ggplot(data = df_data, aes(x = 근무년수, y = 수입)) + geom_line()