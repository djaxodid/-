exam <- read.csv("csv_exam.csv")

head(exam)

tail(exam)

View(exam)

dim(exam)

str(exam)

summary(exam)